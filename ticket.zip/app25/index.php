<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplicación de Ticket</title>
    <!--links de estilo-->
    <?php
    include ("estilo.php");
    ?>
</head>

<body>
    <!--Cabecera-->
    <div class="titulo">
        <h1> UNIVERSO TICKET </h1>
    </div>
    <?php include "cabecera.php"; ?>

    <!--div del cuerpo que contiene dos dentro-->
    <div class="principal">
        <!--div izquierdo del menu ( se puede meter en include )-->
        
        <div class="divizquierdo">
            <?php include 'menu.php';?>
        </div>

        <!--div derecho del contenido-->
        <div class="divderecho">
            <?php include 'contenido.php'; ?>
        </div>

    </div><!--cierra del cuerpo que contiene dos div-->
    <!--pie de pagina-->
    <?php include 'piepagina.php';?>
</body>

</html>