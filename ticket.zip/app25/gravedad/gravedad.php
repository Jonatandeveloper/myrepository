<?php
//conecto a la base de datos
include 'conectarsql.php';

//creo la consulta select de los cargos
$qry = "SELECT * FROM gravedad";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->execute(); //ejecuto la consulta (doy al PLAY)
$resultados = $stmt->get_result(); //obtengo los resultados de la consulta
$array = $resultados->fetch_all(MYSQLI_ASSOC); //aqui ya tengo el array del resultado de la consulta

//Ya puedo montar la tabla en HTML con el foreach
?>
<h1><b>Gravedad:</b></h1>
<br>
<!--boton de crear-->
<a type="button" class="btn btn-primary" href="index.php?tabla=insertar_gravedad"> Insertar </a>
<br><br>

<!--tabla-->
<table class="table table-striped">
    <tr>
        <th>id</th>
        <th>tipo</th>
        <th>codio</th>
        <th class="thbotones"> </th>
    </tr>

    <!--abro php y recorro el array-->
    <?php
    foreach ($array as $clave => $valor) {
        ?>
        <tr>
            <td><?php echo $valor['id'] ?></td>
            <td><?php echo $valor['tipo'] ?></td>
            <td><?php echo $valor['codigo'] ?></td>

            <!--botones de edicion y eliminar-->
            <td>
                <a class="iconotabla" href="index.php?tabla=editar_gravedad&id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botoneditar.png" title="Editar">
                </a>

                <a class="iconotabla" href="gravedad/eliminar.php?id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botonpapelera.png" title="Eliminar">
                </a>
            </td>
        </tr>
        <!--cierro el bucle del array con php-->
        <?php
    }
    ?>
</table>