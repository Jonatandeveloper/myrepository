<?php
//obtengo el los datos que quiero añadir que me viene en el action del formulario mediante POST
$tipo = $_POST['tipo'];
$codigo = $_POST['codigo'];
//incluyo el fichero de conexión a base de datos
include '../conectarsql.php';
//Creo la consulta 
$qry = "INSERT INTO gravedad(tipo, codigo)
        VALUES(?,?)";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param("ss", $tipo, $codigo);
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
//actualizo la tabla dentro del index
header("Location:../index.php?tabla=gravedad");
?>