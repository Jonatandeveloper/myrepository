<div class="menulista">
                <br>
                <a class="amenu" href="index.php?tabla=cargos">
                    <img class="iconos" src="imagenes/icocargo.png" title="Cargos">
                </a>
                <br>
                <a class="amenu" href="index.php?tabla=clientes">
                    <img class="iconos" src="imagenes/icocliente.png" title="Clientes">
                </a>
                <br>
                <a class="amenu" href="index.php?tabla=departamentos">
                     <img class="iconos" src="imagenes/icodepartamento.png" title="Departamentos">
                </a>
                <br>
                <a class="amenu" href="index.php?tabla=estados">
                    <img class="iconos" src="imagenes/icoestado.png" title="Estados"> 
                </a>
                <br>
                <a class="amenu" href="index.php?tabla=gravedad">
                    <img class="iconos" src="imagenes/icogravedad.png" title="Gravedad"> 
                </a><br>
                <a class="amenu" href="index.php?tabla=tecnicos">
                    <img class="iconos" src="imagenes/icotecnico.png" title="Técnicos"> 
                </a><br>
                <a class="amenu" href="index.php?tabla=tickets">
                    <img class="iconos" src="imagenes/icotickets.png" title="Tickets"> 
                </a><br>
                <a class="amenu" href="index.php?tabla=tipo_contrato">
                    <img class="iconos" src="imagenes/icocontrato.png" title="Tipos de Contratos"> 
                </a><br>
                <a class="amenu" href="index.php?tabla=tipo_incidencia">
                    <img class="iconos" src="imagenes/icoincidencia.png" title="Tipos de incidencia"> 
                </a><br>
                <a class="amenu" href="index.php?tabla=turnos">
                    <img class="iconos" src="imagenes/icoturnos.png" title="Turnos"> 
                </a><br>
            </div>