<?php
//conecto a la base de datos
include 'conectarsql.php';

//creo la consulta select de los cargos
$qry = "SELECT * FROM departamentos";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->execute(); //ejecuto la consulta (doy al PLAY)
$resultados = $stmt->get_result(); //obtengo los resultados de la consulta
$array_cargos = $resultados->fetch_all(MYSQLI_ASSOC); //aqui ya tengo el array del resultado de la consulta

//Ya puedo montar la tabla en HTML con el foreach
?>
<h1><b>Departamentos:</b></h1>
<br>
<!--boton crear-->
<a type="button" class="btn btn-primary" href="index.php?tabla=insertar_departamentos"> Insertar </a>
<br><br>

<!--creo la tabla-->
<table class="table table-striped">
    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Responsable</th>
        <th class="thbotones"> </th>
    </tr>
    <!-- abro php para recorrer el array-->
    <?php
    foreach ($array_cargos as $clave => $valor) {
        ?>

        <tr>
            <td><?php echo $valor['id'] ?></td>
            <td><?php echo $valor['nombre'] ?></td>
            <td><?php echo $valor['responsable'] ?></td>

            <!--botones editar y eliminar-->
            <td>
                <a class="iconotabla" href="index.php?tabla=editar_departamento&id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botoneditar.png" title="Editar">
                </a>

                <a class="iconotabla" href="departamentos/eliminar.php?id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botonpapelera.png" title="Eliminar">
                </a>
            </td>
        </tr>
        <!--cierro el bucle de php-->
        <?php
    }
    ?>
</table>