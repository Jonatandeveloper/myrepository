<?php
//obtengo el los datos que quiero añadir que me viene en el action del formulario mediante POST
$nombre = $_POST['nombre'];
$responsable = $_POST['responsable'];
//incluyo el fichero de conexión a base de datos
include '../conectarsql.php';
//Creo la consulta 
$qry = "INSERT INTO departamentos(nombre, responsable)
        VALUES(?,?)";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param("ss", $nombre, $responsable);
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
//actualizo la tabla dentro del index
header("Location:../index.php?tabla=departamentos");
?>