
<!-- muestro formulario html para editar base datos-->
<form method="POST" action="departamentos/editsql.php">
    <div class="mb-3">
        <label class="form-label"><b> Para la ID: </b></label>
        <input class="inputid" readonly type="text" name="id" value="<?php echo $datos_alumno[0]['id'] ?>"><br>
        <label class="form-label"><b> Modificar Nombre: </b></label>
        <input class="form-control" type="text" name="nombre" value="<?php echo $datos_alumno[0]['nombre'] ?>" placeholder="Escribe nombre de alumno"><br>
        <input type="submit" class="btn btn-primary" value="Guardar">
    </div>
</form>


<form method="POST" action="departamentos/editsql.php">
    <div class="mb-3">
        <label class="form-label"><b> Para la ID: </b></label>
        <input class="inputid" readonly type="number" name="id" value="<?php echo $datos[0]['id'] ?>"><br>
    </div>
    <div class="container text-center">
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar el nombre</b></label>
                <input type="text" name="nombre" value="<?php echo $datos[0]['nombre'] ?>" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresar la descripción: </b></label>
                <input type="text" name="responsable" value="<?php echo $datos[0]['responsable'] ?>"
                    class="form-control">
            </div>
        </div>
        <br>
    </div>
    <!--boton-->
    <button type="submit" class="btn btn-primary">Guardar</button>
</form>
  