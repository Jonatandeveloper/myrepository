<!--formulario para ingresar nuevos datos-->
<form class="inputdiv" method="POST" action="tipo_incidencia/insertsql.php">

    <div class="container text-center">
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar el tipo</b></label>
                <input type="text" name="tipo" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresar el codigo: </b></label>
                <input type="text" name="codigo" class="form-control">
            </div>
        </div>
        <br>
    </div>
    <!--boton-->
    <button type="submit" class="btn btn-primary">Guardar</button>
</form>