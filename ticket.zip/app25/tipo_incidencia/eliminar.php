<?php
//obtengo el ID que quiero eliminar que me viene en la URL
$id = $_GET['id'];
//incluyo el fichero de conexión a base de datos
include '../conectarsql.php';
//Creo la consulta 
$qry = "DELETE FROM tipos_incidencia WHERE id=?";
$stmt = $conn -> prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param("i", $id);
$stmt -> execute();//ejecuto la consulta (equivalente a play sql) 
//actualizo la tabla dentro del index
header("Location:../index.php?tabla=tipo_incidencia");
?>