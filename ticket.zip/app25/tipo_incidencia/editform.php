<?php
//Obtengo la ID que voy a editar
$id = $_GET['id'];
//Tengo que consultar en la tabla los campos y valores de ese ID
include 'conectarsql.php';
//Creo la consulta 
$qry = "SELECT * FROM tipos_incidencia WHERE id=?";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param("i", $id);
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
$resultados = $stmt->get_result(); //obtengo los resultados de la consulta
$datos = $resultados->fetch_all(MYSQLI_ASSOC);
?>

<!-- muestro formulario html para editar base datos-->
<form method="POST" action="tipo_incidencia/editsql.php">
    <div class="mb-3">
        <label class="form-label"><b> Para la ID: </b></label>
        <input class="inputid" readonly type="text" name="id" value="<?php echo $datos[0]['id'] ?>"><br>
    </div>
    <div class="container text-center">
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresa el tipo: </b></label>
                <input type="text" name="tipo" value="<?php echo $datos[0]['tipo'] ?>" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresa el código: </b></label>
                <input type="text" name="codigo" value="<?php echo $datos[0]['codigo'] ?>" class="form-control">
            </div>
        </div>
        <br>
    </div>
    <!--boton-->
    <button type="submit" class="btn btn-primary">Guardar</button>
</form>