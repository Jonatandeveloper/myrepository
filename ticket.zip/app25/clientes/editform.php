<?php
//Obtengo la ID que voy a editar
$id = $_GET['id'];
//Tengo que consultar en la tabla los campos y valores de ese ID
include 'conectarsql.php';
//Creo la consulta 
$qry = "SELECT * FROM clientes WHERE id=?";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param("i", $id);
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
$resultados = $stmt->get_result(); //obtengo los resultados de la consulta
$datos = $resultados->fetch_all(MYSQLI_ASSOC);
?>

<!-- muestro formulario html para editar base datos-->

<form class="inputdiv" method="POST" action="clientes/insertsql.php">

    <div class="mb-3">
        <label class="form-label"><b> Para la ID: </b></label>
        <input class="inputid" readonly type="number" name="id" value="<?php echo $datos[0]['id'] ?>"><br>
    </div>

    <div class="container text-center">
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar el nombre: </b></label>
                <input type="text" name="nombre" value="<?php echo $datos[0]['nombre'] ?>" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresa el telefono: </b></label>
                <input type="text" name="telefono" value="<?php echo $datos[0]['telefono'] ?>" class="form-control">
            </div>
        </div>

        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresa el email </b></label>
                <input type="mail" name="email" value="<?php echo $datos[0]['email'] ?>" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresar la dirección: </b></label>
                <input type="text" name="direccion" value="<?php echo $datos[0]['direccion'] ?>" class="form-control">
            </div>
        </div>

        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresa el CP: </b></label>
                <input type="number" name="cp" value="<?php echo $datos[0]['cp'] ?>" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresa la Provincia: </b></label>
                <input type="text" name="provincia" value="<?php echo $datos[0]['provincia'] ?>" class="form-control">
            </div>
        </div>

        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar el País: </b></label>
                <input type="text" name="pais" value="<?php echo $datos[0]['pais'] ?>" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresa la persona de contacto </b></label>
                <input type="text" name="persona_contacto" value="<?php echo $datos[0]['persona_contacto'] ?>"class="form-control">
            </div>
        </div>
        
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresa el tipo de contrato </b></label>
                <input type="text" name="tipo_contrato" value="<?php echo $datos[0]['tipo_contrato'] ?>"
                    class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresa el iban: </b></label>
                <input type="text" name="iban" value="<?php echo $datos[0]['iban'] ?>" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresa el nif </b></label>
                <input type="text" name="nif" value="<?php echo $datos[0]['nif'] ?>" class="form-control">
            </div>
        </div>
        <br>
    </div>
    <!--boton-->
    <button type="submit" class="btn btn-primary">Guardar</button>
</form>