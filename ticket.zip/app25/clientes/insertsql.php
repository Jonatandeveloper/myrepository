<?php
//obtengo el los datos que quiero añadir que me viene en el action del formulario mediante POST
$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$email = $_POST['email'];
$direccion = $_POST['direccion'];
$cp = $_POST['cp'];
$provincia = $_POST['provincia'];
$pais = $_POST['pais'];
$persona_contacto = $_POST['persona_contacto'];
$tipo_contrato = $_POST['tipo_contrato'];
$iban = $_POST['iban'];
$nif = $_POST['nif'];
//incluyo el fichero de conexión a base de datos
include '../conectarsql.php';
//Creo la consulta 
$qry = "INSERT INTO clientes(nombre, telefono, email, direccion, cp, 
                    provincia, pais, persona_contacto, tipo_contrato, iban, nif)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param(
        "ssssissssss",
        $nombre,
        $telefono,
        $email,
        $direccion,
        $cp,
        $provincia,
        $pais,
        $persona_contacto,
        $tipo_contrato,
        $iban,
        $nif
);
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
//actualizo la tabla dentro del index
header("Location:../index.php?tabla=clientes");
?>