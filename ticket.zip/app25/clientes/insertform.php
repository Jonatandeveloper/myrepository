<!--formulario para ingresar nuevos datos-->

<form class="inputdiv" method="POST" action="clientes/insertsql.php">
    <div class="container text-center">
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar el nombre: </b></label>
                <input type="text" name="nombre" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresa el telefono: </b></label>
                <input type="text" name="telefono" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresa el email </b></label>
                <input type="mail" name="email" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresar la dirección: </b></label>
                <input type="text" name="direccion" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresa el CP: </b></label>
                <input type="number" name="cp" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresa la Provincia: </b></label>
                <input type="text" name="provincia" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar el País: </b></label>
                <input type="text" name="pais" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresa la persona de contacto </b></label>
                <input type="text" name="persona_contacto" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresa el tipo de contrato </b></label>
                <input type="text" name="tipo_contrato" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresa el iban: </b></label>
                <input type="text" name="iban" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresa el nif </b></label>
                <input type="text" name="nif" class="form-control">
            </div>
        </div>
        <br>
    </div>
    <!--boton-->
    <button type="submit" class="btn btn-primary">Guardar</button>
</form>