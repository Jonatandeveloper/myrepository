<?php
//Recojo TODOS los campos del formulario de edición que me llegan por POST
$id = $_POST['id'];
$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$email = $_POST['email'];
$direccion = $_POST['direccion']
$cp = $_POST['cp'];
$provincia = $_POST['provincia'];
$pais = $_POST['pais'];
$persona_contacto = $_POST['persona_contacto'];
$tipo_contrato = $_POST['tipo_contrato'];
$iban = $_POST['iban'];
$nif = $_POST['nif'];


//conecto a la base datos
include '../conectarsql.php';
//Creo la consulta 
$qry = "UPDATE clientes SET nombre=?, telefono=?, email=?, direccion=?, cp=?, 
                provincia=?, pais=?, persona_contacto=?, tipo_contrato=?, iban=?, nif=?,
        WHERE id = ?";
        
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param(
        "ssssissssssi",
        $nombre,
        $telefono,
        $email,
        $direccion,
        $cp,
        $provincia,
        $pais,
        $persona_contacto,
        $tipo_contrato,
        $iban,
        $nif,
        $id
); //s=texto  i=numerico
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
//actualizo la tabla dentro del index
header("Location:../index.php?tabla=clientes");
?>