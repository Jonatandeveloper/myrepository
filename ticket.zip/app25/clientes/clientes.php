<?php
//conecto a la base de datos
include 'conectarsql.php';

//creo la consulta select de los cargos
$qry = "SELECT * FROM clientes";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->execute(); //ejecuto la consulta (doy al PLAY)
$resultados = $stmt->get_result(); //obtengo los resultados de la consulta
$array_clientes = $resultados->fetch_all(MYSQLI_ASSOC); //aqui ya tengo el array del resultado de la consulta

//Ya puedo montar la tabla en HTML con el foreach
?>
<h1><b>Clientes:</b></h1>
<br>
<!--boton para crear -->
<a type="button" class="btn btn-primary" href="index.php?tabla=insertar_cliente"> Insertar </a>
<br><br>


<!--tabla-->
<table class="table table-striped">
    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Telefono</th>
        <th>Email</th>
        <th>Direccion</th>
        <th>CP</th>
        <th>Provincia</th>
        <th>Pais</th>
        <th>Persona Contacto</th>
        <th>Tipo contrato</th>
        <th>Iban</th>
        <th>NIF</th>
        <th class="thbotones"> </th>
    </tr>

    <!--abro php y recorro el array-->
    <?php
    foreach ($array_clientes as $clave => $valor) {
        ?>

        <tr>
            <td><?php echo $valor['id'] ?></td>
            <td><?php echo $valor['nombre'] ?></td>
            <td><?php echo $valor['telefono'] ?></td>
            <td><?php echo $valor['email'] ?></td>
            <td><?php echo $valor['direccion'] ?></td>
            <td><?php echo $valor['cp'] ?></td>
            <td><?php echo $valor['provincia'] ?></td>
            <td><?php echo $valor['pais'] ?></td>
            <td><?php echo $valor['persona_contacto'] ?></td>
            <td><?php echo $valor['tipo_contrato'] ?></td>
            <td><?php echo $valor['iban'] ?></td>
            <td><?php echo $valor['nif'] ?></td>
            <!--Pongo los botones de edicion y eliminar-->
            <td>
                <a class="iconotabla" href="index.php?tabla=editar_clientes&id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botoneditar.png" title="Editar">
                </a>

                <a class="iconotabla" href="clientes/eliminar.php?id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botonpapelera.png" title="Eliminar">
                </a>
            </td>
        </tr>

        <!--cierro el bucle del array-->
        <?php
    }
    ?>
</table>