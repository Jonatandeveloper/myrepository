<?php
//variable tabla vacia para que en caso de no enviarle nada por GET, dentro del switch
//vaya directamente al default
$tabla = "";

//si le paso la tabla por url (GET), Obtengo la tabla enviada por GET (url)
if (isset($_GET["tabla"]) == true) {
    $tabla = $_GET['tabla'];
}
//Dependiendo de la tabla, haré una consulta o haré otra
switch ($tabla) {
    case 'cargos':
        include 'cargos/cargos.php';
        break;

    case 'clientes':
        include 'clientes/clientes.php';
        break;

    case 'departamentos':
        include 'departamentos/departamentos.php';
        break;

    case 'estados':
        include 'estados/estados.php';
        break;

    case 'gravedad':
        include 'gravedad/gravedad.php';
        break;

    case 'tecnicos':
        include 'tecnicos/tecnicos.php';
        break;

    case 'tickets':
        include 'tickets/tickets.php';
        break;

    case 'tipo_contrato':
        include 'tipo_contrato/tipo_contrato.php';
        break;

    case 'tipo_incidencia':
        include 'tipo_incidencia/tipo_incidencia.php';
        break;

    case 'turnos':
        include 'turnos/turnos.php';
        break;

    //insertar
    case 'insertar_cargo':
        include 'cargos/insertform.php';
        break;

    case 'insertar_cliente':
        include 'clientes/insertform.php';
        break;

    case 'insertar_departamentos':
        include 'departamentos/insertform.php';
        break;

    case 'insertar_estado':
        include 'estados/insertform.php';
        break;

    case 'insertar_gravedad':
        include 'gravedad/insertform.php';
        break;

    case 'insertar_tecnico':
        include 'tecnicos/insertform.php';
        break;

    case 'insertar_ticket':
        include 'tickets/insertform.php';
        break;

    case 'insertar_tipo_contrato':
        include 'tipo_contrato/insertform.php';
        break;

    case 'insertar_tipo_incidencia':
        include 'tipo_incidencia/insertform.php';
        break;

    case 'insertar_turno':
        include 'turnos/insertform.php';
        break;

    //editar
    case 'editar_cargo':
        include 'cargos/editform.php';
        break;

    case 'editar_clientes':
        include 'clientes/editform.php';
        break;

    case 'editar_departamento':
        include 'departamentos/editform.php';
        break;

    case 'editar_estado':
        include 'estados/editform.php';
        break;

    case 'editar_gravedad':
        include 'gravedad/editform.php';
        break;

    case 'editar_tecnico':
        include 'tecnicos/editform.php';
        break;

    case 'editar_ticket':
        include 'tickets/editform.php';
        break;

    case 'editar_tipo_contrato':
        include 'tipo_contrato/editform.php';
        break;

    case 'editar_tipo_incidencia':
        include 'tipo_incidencia/editform.php';
        break;

    case 'editar_turno':
        include 'turnos/editform.php';
        break;

    default:
        break;
}
?>