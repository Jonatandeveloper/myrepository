<?php
//parametros de conexion
$server = "localhost";
$usuario = "root";
$pwd = "";
$dbname = "tickets";
//Conecto
$conn = new mysqli($server, $usuario, $pwd, $dbname);
?>