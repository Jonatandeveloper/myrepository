<?php
//conecto a la base de datos
include 'conectarsql.php';
//creo la consulta select de los cargos
$qry = "SELECT * FROM cargos";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
$resultados = $stmt->get_result(); //obtengo los resultados de la consulta
$array_cargos = $resultados->fetch_all(MYSQLI_ASSOC); //aqui ya tengo el array del resultado de la consulta
?>

<!--Ya puedo montar la tabla en HTML con el foreach-->
<h1><b>Cargos:</b></h1>
<br>
<a type="button" class="btn btn-primary" href="index.php?tabla=insertar_cargo"> Insertar </a>
<br><br>

<!--tabla-->
<table class="table table-hover table-responsive ">
    <tr>
        <th>ID</th>
        <th>CARGO</th>
        <th class="thbotones"> </th>
    </tr>
    <!--abro php y recorro el array-->
    <?php
    foreach ($array_cargos as $clave => $valor) {
        ?>
        <tr>
            <td><?php echo $valor['id'] ?></td>
            <td><?php echo $valor['nombre'] ?></td>
            <td>
                <!--botones para editar y eliminar-->
                <a class="iconotabla" href="index.php?tabla=editar_cargo&id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botoneditar.png" title="Editar">
                </a>

                <a class="iconotabla" href="cargos/eliminar.php?id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botonpapelera.png" title="Eliminar">
                </a>
            </td>
        </tr>
        <!--cierro el bucle del array-->
        <?php
    }
    ?>
</table>