<!--formulario para ingresar nuevos datos-->
<form method="POST" action="cargos/insertsql.php">
    <div class="mb-3">
        <label class="form-label"><b> Ingresar: </b></label>
        <input type="text" name="nombre" class="form-control">
    </div>
    <!--boton-->
    <button type="submit" class="btn btn-primary">Guardar</button>
</form>