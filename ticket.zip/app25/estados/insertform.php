<!--formulario para ingresar nuevos datos-->
<form class="inputdiv" method="POST" action="estados/insertsql.php">
    <div class="container text-center">
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar el nombre:</b></label>
                <input type="text" name="nombre" class="form-control">
            </div>
        </div>
        <br>
    </div>
    <!--boton-->
    <button type="submit" class="btn btn-primary">Guardar</button>
</form>