<?php
//Recojo TODOS los campos del formulario de edición que me llegan por POST
$id = $_POST['id'];
$codigo_ticket = $_POST['codigo_ticket'];
$fecha_ticket = $_POST['fecha_ticket'];
$id_gravedad = $_POST['id_gravedad'];
$id_tipo = $_POST['id_tipo'];
$id_tecnico = $_POST['id_tecnico'];
$id_estado = $_POST['id_estado'];
$id_cliente = $_POST['id_cliente'];
$descripcion = $_POST['descripcion'];
$tareas = $_POST['tareas'];
$fecha_cierre = $_POST['fecha_cierre'];
$valoracion = $_POST['valoracion'];

//conecto a la base datos
include '../conectarsql.php';
//Creo la consulta 
$qry = "UPDATE ticket SET codigo_ticket=?, fecha_ticket=?, id_gravedad=?, id_tipo=?, id_tecnico=?, id_estado=?, id_cliente=?, descripcion=?, tareas=?, fecha_cierre=?, valoracion=?
        WHERE id = ?";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param(
        "ssiiiiisssii",
        $codigo_ticket,
        $fecha_ticket,
        $id_gravedad,
        $id_tipo,
        $id_tecnico,
        $id_estado,
        $id_cliente,
        $descripcion,
        $tareas,
        $fecha_cierre,
        $valoracion,
        $id
); //s=texto  i=numerico
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
//actualizo la tabla dentro del index
header("Location:../index.php?tabla=tickets");
?>