<?php
//obtengo el los datos que quiero añadir que me viene en el action del formulario mediante POST
$codigo_ticket = $_POST['codigo_ticket'];
$fecha_ticket = $_POST['fecha_ticket'];
$id_gravedad = $_POST['id_gravedad'];
$id_tipo = $_POST['id_tipo'];
$id_tecnico = $_POST['id_tecnico'];
$id_estado = $_POST['id_estado'];
$id_cliente = $_POST['id_cliente'];
$descripcion = $_POST['descripcion'];
$tareas = $_POST['tareas'];
$fecha_cierre = $_POST['fecha_cierre'];
$valoracion = $_POST['valoracion'];

//incluyo el fichero de conexión a base de datos
include '../conectarsql.php';
//Creo la consulta 
$qry = "INSERT INTO ticket(codigo_ticket, fecha_ticket, id_gravedad, id_tipo, id_tecnico, id_estado, id_cliente, descripcion, tareas, fecha_cierre, valoracion)
VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn -> prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param("ssiiiiisssi", $codigo_ticket, $fecha_ticket, $id_gravedad, $id_tipo, $id_tecnico, $id_estado, $id_cliente, $descripcion, $tareas, $fecha_cierre, $valoracion);
$stmt -> execute(); //ejecuto la consulta (equivalente a play sql)
//actualizo la tabla dentro del index
header("Location:../index.php?tabla=tickets");
?>