<!--formulario para ingresar nuevos datos-->
<form class="inputdiv" method="POST" action="tickets/insertsql.php">
    <div class="container text-center">
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar el codigo ticket </b></label>
                <input type="text" name="codigo_ticket" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresar fecha ticket: </b></label>
                <input type="date" name="fecha_ticket" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar id_gravedad: </b></label>
                <input type="text" name="id_gravedad" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresar id_tipo: </b></label>
                <input type="text" name="id_tipo" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar el ID de tecnico: </b></label>
                <input type="text" name="id_tecnico" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresar el ID de estado: </b></label>
                <input type="text" name="id_estado" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar El ID de cliente: </b></label>
                <input type="text" name="id_cliente" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresar descripcion </b></label>
                <input type="text" name="descripcion" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar tareas: </b></label>
                <input type="text" name="tareas" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Ingresar la fecha de cierre: </b></label>
                <input type="date" name="fecha_cierre" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar valoración: </b></label>
                <input type="text" name="valoracion" class="form-control">
            </div>
        </div>
        <br>
    </div>
    <!--boton-->
    <button type="submit" class="btn btn-primary">Guardar</button>
</form>