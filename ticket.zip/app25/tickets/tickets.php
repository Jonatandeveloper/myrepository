<?php
//conecto a la base de datos
include 'conectarsql.php';
//creo la consulta select de los tickets
$qry = "SELECT * FROM ticket";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
$resultados = $stmt->get_result(); //obtengo los resultados de la consulta
$array_ticket = $resultados->fetch_all(MYSQLI_ASSOC); //aqui ya tengo el array del resultado de la consulta
?>

<!--Ya puedo montar la tabla en HTML con el foreach-->
<h1><b>Tickets:</b></h1>
<br>
<a type="button" class="btn btn-primary" href="index.php?tabla=insertar_ticket"> Insertar </a>
<br><br>

<!--tabla-->
<table class="table table-hover table-responsive ">
    <tr>
        <th>ID</th>
        <th>Codigo Ticket</th>
        <th>Fecha tikcet</th>
        <th>ID Gravedad</th>
        <th>ID tipo</th>
        <th>ID Tecnico</th>
        <th>ID estado</th>
        <th>ID cliente</th>
        <th>Descripcion</th>
        <th>Tareas</th>
        <th>Fecha cierra</th>
        <th>Valoracion</th>
        <th class="thbotones"> </th>
    </tr>
    <!--abro php para recorrer array-->
    <?php
    foreach ($array_ticket as $clave => $valor) {
        ?>
        <tr>
            <td><?php echo $valor['id'] ?></td>
            <td><?php echo $valor['codigo_ticket'] ?></td>
            <td><?php echo $valor['fecha_ticket'] ?></td>
            <td><?php echo $valor['id_gravedad'] ?></td>
            <td><?php echo $valor['id_tipo'] ?></td>
            <td><?php echo $valor['id_tecnico'] ?></td>
            <td><?php echo $valor['id_estado'] ?></td>
            <td><?php echo $valor['id_cliente'] ?></td>
            <td><?php echo $valor['descripcion'] ?></td>
            <td><?php echo $valor['tareas'] ?></td>
            <td><?php echo $valor['fecha_cierre'] ?></td>
            <td><?php echo $valor['valoracion'] ?></td>
            <!--botones editar y eliminar-->
            <td>
                <!--botones para editar y eliminar-->
                <a class="iconotabla" href="index.php?tabla=editar_ticket&id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botoneditar.png" title="Editar">
                </a>

                <a class="iconotabla" href="tickets/eliminar.php?id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botonpapelera.png" title="Eliminar">
                </a>
            </td>
        </tr>
        <!-- cierro el bucle de php-->
        <?php
    }
    ?>
</table>