<?php
//Recojo TODOS los campos del formulario de edición que me llegan por POST
$id = $_POST['id'];
$nombre = $_POST['nombre'];
$descripcion = $_POST['descripcion'];

//conecto a la base datos
include '../conectarsql.php';
//Creo la consulta 
$qry = "UPDATE turnos SET nombre=?, descripcion=?
        WHERE id = ?";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param("ssi", $nombre, $descripcion, $id); //s=texto  i=numerico
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
//actualizo la tabla dentro del index
header("Location:../index.php?tabla=turnos");
?>