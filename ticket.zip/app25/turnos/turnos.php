<?php
//conecto a la base de datos
include 'conectarsql.php';
//creo la consulta select de los turnos
$qry = "SELECT * FROM turnos";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
$resultados = $stmt->get_result(); //obtengo los resultados de la consulta
$array_turnos = $resultados->fetch_all(MYSQLI_ASSOC); //aqui ya tengo el array del resultado de la consulta
?>

<!--Ya puedo montar la tabla en HTML con el foreach-->
<h1><b>Turnos:</b></h1>
<br>
<a type="button" class="btn btn-primary" href="index.php?tabla=insertar_turno"> Insertar </a>
<br><br>

<!--tabla-->
<table class="table table-hover table-responsive ">
    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Descripcion</th>
        <th class="thbotones"> </th>
    </tr>
    <!--habro php para recorrer array-->
    <?php
    foreach ($array_turnos as $clave => $valor) {
        ?>
        <!--cierro php y imprimo valores-->
        <tr>
            <td><?php echo $valor['id'] ?></td>
            <td><?php echo $valor['nombre'] ?></td>
            <td><?php echo $valor['descripcion'] ?></td>
            <td>
                <!--botones para editar y eliminar-->
                <a class="iconotabla" href="index.php?tabla=editar_turno&id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botoneditar.png" title="Editar">
                </a>

                <a class="iconotabla" href="turnos/eliminar.php?id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botonpapelera.png" title="Eliminar">
                </a>
            </td>
        </tr>
        <!--cierro el bucle de php-->
        <?php
    }
    ?>

</table>