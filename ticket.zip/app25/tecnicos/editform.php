<?php
//Obtengo la ID que voy a editar
$id = $_GET['id'];
//Tengo que consultar en la tabla los campos y valores de ese ID
include 'conectarsql.php';
//Creo la consulta 
$qry = "SELECT * FROM tecnicos WHERE id=?";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param("i", $id);
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
$resultados = $stmt->get_result(); //obtengo los resultados de la consulta
$datos = $resultados->fetch_all(MYSQLI_ASSOC);
?>

<!-- muestro formulario html para editar base datos-->
<form method="POST" action="tecnicos/editsql.php">
    <div class="mb-3">
        <label class="form-label"><b> Para la ID: </b></label>
        <input class="inputid" readonly type="text" name="id" value="<?php echo $datos[0]['id'] ?>"><br>
    </div>

    <div class="container text-center">
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar el código de empleado: </b></label>
                <input type="text" name="cod_empleado" value="<?php echo $datos[0]['cod_empleado'] ?>"
                    class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Nombre: </b></label>
                <input type="text" name="nombre" value="<?php echo $datos[0]['nombre'] ?>" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Apellidos: </b></label>
                <input type="text" name="apellido" value="<?php echo $datos[0]['apellido'] ?>" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Teléfono de contacto: </b></label>
                <input type="text" name="telefono" value="<?php echo $datos[0]['telefono'] ?>" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> e-mail de contacto: </b></label>
                <input type="text" name="email" value="<?php echo $datos[0]['email'] ?>" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Departamento: </b></label>
                <input type="text" name="departamento" value="<?php echo $datos[0]['departamento'] ?>"
                    class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Turno: </b></label>
                <input type="text" name="turno" value="<?php echo $datos[0]['turno'] ?>" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Fecha de contratación: </b></label>
                <input type="date" name="fecha_contrato" value="<?php echo $datos[0]['fecha_contrato'] ?>"
                    class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Cargo: </b></label>
                <input type="text" name="cargo" value="<?php echo $datos[0]['cargo'] ?>" class="form-control">
            </div>
        </div>
        <br>
    </div>
    <!--boton-->
    <button type="submit" class="btn btn-primary">Guardar</button>
</form>