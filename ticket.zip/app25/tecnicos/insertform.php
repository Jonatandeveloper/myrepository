<!--formulario para ingresar nuevos datos-->
<form method="POST" action="tecnicos/insertsql.php">
<div class="container text-center">
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Ingresar el código de empleado: </b></label>
                <input type="text" name="cod_empleado" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Nombre: </b></label>
                <input type="text" name="nombre" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Apellidos: </b></label>
                <input type="text" name="apellido" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Teléfono de contacto: </b></label>
                <input type="text" name="telefono" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> e-mail de contacto: </b></label>
                <input type="text" name="email" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Departamento: </b></label>
                <input type="text" name="departamento" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Turno: </b></label>
                <input type="text" name="turno" class="form-control">
            </div>
            <div class="col-4">
                <label class="form-label"><b> Fecha de contratación: </b></label>
                <input type="date" name="fecha_contrato" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label class="form-label"><b> Cargo: </b></label>
                <input type="text" name="cargo" class="form-control">
            </div>
        </div>
        <br>
    </div>
    <!--boton-->
    <button type="submit" class="btn btn-primary">Guardar</button>
</form>