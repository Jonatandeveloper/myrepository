<?php
//obtengo el los datos que quiero añadir que me viene en el action del formulario mediante POST
$cod_empleado = $_POST['cod_empleado'];
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$telefono = $_POST['telefono'];
$email = $_POST['email'];
$departamento = $_POST['departamento'];
$turno = $_POST['turno'];
$fecha_contrato = $_POST['fecha_contrato'];
$cargo = $_POST['cargo'];
//incluyo el fichero de conexión a base de datos
include '../conectarsql.php';
//Creo la consulta 
$qry = "INSERT INTO tecnicos(cod_empleado, nombre, apellido, telefono, email, departamento, turno, fecha_contrato, cargo)
        VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn -> prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param("sssssiisi", $cod_empleado, $nombre, $apellido, $telefono, $email, $departamento, $turno, $fecha_contrato, $cargo);
$stmt -> execute(); //ejecuto la consulta (equivalente a play sql)
//actualizo la tabla dentro del index
header("Location:../index.php?tabla=tecnicos");
?>