<?php
//conecto a la base de datos
include 'conectarsql.php';

//creo la consulta select de los cargos
$qry = "SELECT * FROM tecnicos";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->execute(); //ejecuto la consulta (doy al PLAY)
$resultados = $stmt->get_result(); //obtengo los resultados de la consulta
$array_tecnicos = $resultados->fetch_all(MYSQLI_ASSOC); //aqui ya tengo el array del resultado de la consulta
?>

<!--Ya puedo montar la tabla en HTML con el foreach-->
<h1><b>Técnicos:</b></h1>
<br>
<a type="button" class="btn btn-primary" href="index.php?tabla=insertar_tecnico"> Insertar </a>
<br><br>

<!--creo tabla-->
<table class="table table-hover table-responsive tablamedia">
    <tr>
        <th>id</th>
        <th>cod_empleado</th>
        <th>nombre</th>
        <th>apellido</th>
        <th>telefono</th>
        <th>email</th>
        <th>departamento</th>
        <th>turno</th>
        <th>fecha contrato</th>
        <th>cargo</th>
        <th class="thbotones"> </th>
    </tr>
    <!--recorro array-->
    <?php
    foreach ($array_tecnicos as $clave => $valor) {
        ?>
        <tr>
            <td><?php echo $valor['id'] ?></td>
            <td><?php echo $valor['cod_empleado'] ?></td>
            <td><?php echo $valor['nombre'] ?></td>
            <td><?php echo $valor['apellido'] ?></td>
            <td><?php echo $valor['telefono'] ?></td>
            <td><?php echo $valor['email'] ?></td>
            <td><?php echo $valor['departamento'] ?></td>
            <td><?php echo $valor['turno'] ?></td>
            <td><?php echo $valor['fecha_contrato'] ?></td>
            <td><?php echo $valor['cargo'] ?></td>
            <!--botones editar y eliminar-->
            <td>
                <a class="iconotabla" href="index.php?tabla=editar_tecnico&id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botoneditar.png" title="Editar">
                </a>

                <a class="iconotabla" href="tecnicos/eliminar.php?id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botonpapelera.png" title="Eliminar">
                </a>
            </td>
        </tr>
        <!-- cierro el bucle de php-->
        <?php
    }
    ?>
</table>