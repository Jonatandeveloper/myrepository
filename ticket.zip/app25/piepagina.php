<div class="card">
        <div class="card-header programador">
            Desarrollado por Jonatan Jimenez
        </div>

        <div class="card-body">
            <h5 class="card-title"></h5>
            <div class="divcaja">
                <span class="card-text contacto"> <b>Contacto para colaboraciones:</b> nervion.jj@hotmail.com</span>

                <!--logos-->
                <img class="logoyt" src="imagenes/yt.png" title="youtube">
                <img class="logopajaro" src="imagenes/pajaro.png">
                <img class="logofc" src="imagenes/face.png">
            </div>
        </div>
    </div>