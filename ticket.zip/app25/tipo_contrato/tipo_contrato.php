<?php
//conecto a la base de datos
include 'conectarsql.php';
//creo la consulta select de los cargos
$qry = "SELECT * FROM tipos_contrato";
$stmt = $conn->prepare($qry); //preparo la consulta en la conexion establecida
$stmt->execute(); //ejecuto la consulta (equivalente a play sql)
$resultados = $stmt->get_result(); //obtengo los resultados de la consulta
$array_tipos_contrato = $resultados->fetch_all(MYSQLI_ASSOC); //aqui ya tengo el array del resultado de la consulta
?>

<!--Ya puedo montar la tabla en HTML con el foreach-->
<h1><b>Tipos de Contrato:</b></h1>
<br>
<a type="button" class="btn btn-primary" href="index.php?tabla=insertar_tipo_contrato"> Insertar </a>
<br><br>

<!--tabla-->
<table class="table table-hover table-responsive ">
    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th class="thbotones"> </th>
    </tr>
    <!--abro php para recorrer array-->
    <?php
    foreach ($array_tipos_contrato as $clave => $valor) {
        ?>

        <tr>
            <td><?php echo $valor['id'] ?></td>
            <td><?php echo $valor['nombre'] ?></td>
            <td>
                <!--botones para editar y eliminar-->
                <a class="iconotabla" href="index.php?tabla=editar_tipo_contrato&id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botoneditar.png" title="Editar">
                </a>

                <a class="iconotabla" href="tipo_contrato/eliminar.php?id=<?php echo $valor['id'] ?>">
                    <img src="imagenes/botonpapelera.png" title="Eliminar">
                </a>
            </td>
        </tr>
        <!--cierro bucle de php-->
        <?php
    }
    ?>
</table>