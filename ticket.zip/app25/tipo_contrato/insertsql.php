<?php
//obtengo el los datos que quiero añadir que me viene en el action del formulario mediante POST
$nombre = $_POST['nombre'];
//incluyo el fichero de conexión a base de datos
include '../conectarsql.php';
//Creo la consulta 
$qry = "INSERT INTO tipos_contrato(nombre)
        VALUES( ?)";
$stmt = $conn -> prepare($qry); //preparo la consulta en la conexion establecida
$stmt->bind_param("s", $nombre);
$stmt -> execute(); //ejecuto la consulta (equivalente a play sql)
//actualizo la tabla dentro del index
header("Location:../index.php?tabla=tipo_contrato");
?>