---

# Sudoku Jonatan Jimenez Pulido
# This is a Sudoku app 2.0. 
# For play open in VScode, open de terminal and put cargo run. Copy the direccion in the navegator and press enter. You can ready for play.