//Imports
use actix_files as fs;
use actix_web::{web, App, HttpResponse, HttpServer, Responder};
use rand::thread_rng;
use rand::Rng;
use std::io;
use tera::{Context, Tera};

//function principal rute
async fn index(tera: web::Data<Tera>) -> impl Responder {
    let mut context = Context::new();
    // Sudoky ready for play
    context.insert("sudoku", &create_sudoku_grid_for_play());
    // Rendered index.html with sudoku data
    let rendered = tera.render("index.html", &context).unwrap();
    // Response with code generate
    HttpResponse::Ok().content_type("text/html").body(rendered)
}

//Function solution
async fn get_solution() -> impl Responder {
    // Retorn the all solution
    let solution = create_sudoku_grid_solution(); // Usamos la solución completa
                                                  //json solution
    HttpResponse::Ok().json(solution)
}

//function sudoku grid with emty box
fn create_sudoku_grid_for_play() -> Vec<Vec<Option<u8>>> {
    //Get complete solution
    let solution = create_sudoku_grid_solution();
    //Clone solution for play
    let mut puzzle = solution.clone();
    //Start random generator numbers
    let mut rng = thread_rng();
    //Record empty cell
    let mut hidden_cells = Vec::new();
    //empty 40 aleatory box
    for _ in 0..40 {
        let row = rng.gen_range(0..=8);
        let col = rng.gen_range(0..=8);
        // If the cell has not been emptied before, we empty it
        if !hidden_cells.contains(&(row, col)) {
            puzzle[row][col] = None;
            hidden_cells.push((row, col));
        }
    }
    //return the Sudoku with empty cells
    puzzle
}

// Sudoku solution
fn create_sudoku_grid_solution() -> Vec<Vec<Option<u8>>> {
    vec![
        vec![
            Some(5),
            Some(3),
            Some(4),
            Some(6),
            Some(7),
            Some(8),
            Some(9),
            Some(1),
            Some(2),
        ],
        vec![
            Some(6),
            Some(7),
            Some(2),
            Some(1),
            Some(9),
            Some(5),
            Some(3),
            Some(4),
            Some(8),
        ],
        vec![
            Some(1),
            Some(9),
            Some(8),
            Some(3),
            Some(4),
            Some(2),
            Some(5),
            Some(6),
            Some(7),
        ],
        vec![
            Some(8),
            Some(5),
            Some(9),
            Some(7),
            Some(6),
            Some(1),
            Some(4),
            Some(2),
            Some(3),
        ],
        vec![
            Some(4),
            Some(2),
            Some(6),
            Some(8),
            Some(5),
            Some(3),
            Some(7),
            Some(9),
            Some(1),
        ],
        vec![
            Some(7),
            Some(1),
            Some(3),
            Some(9),
            Some(2),
            Some(4),
            Some(8),
            Some(5),
            Some(6),
        ],
        vec![
            Some(9),
            Some(6),
            Some(1),
            Some(5),
            Some(3),
            Some(7),
            Some(2),
            Some(8),
            Some(4),
        ],
        vec![
            Some(2),
            Some(8),
            Some(7),
            Some(4),
            Some(1),
            Some(9),
            Some(6),
            Some(3),
            Some(5),
        ],
        vec![
            Some(3),
            Some(4),
            Some(5),
            Some(2),
            Some(8),
            Some(6),
            Some(1),
            Some(7),
            Some(9),
        ],
    ]
}

// Principal function that starts the web server
#[actix_web::main]
async fn main() -> io::Result<()> {
    //initialize the Tera template engine with the templates located in "static/templates/**/*"
    let tera = Tera::new("static/templates/**/*").unwrap();
    println!("Starting server on 127.0.0.1:8080");
    //create the HTTP server and settinf the rutes and service
    HttpServer::new(move || {
        //create new app
        App::new()
            //register the Tera engine so that it is available on the routes
            .app_data(web::Data::new(tera.clone()))
            // Main path that calls the "index" function to display the playable Sudoku
            .route("/", web::get().to(index))
            //Retorn the solution sudoku
            .route("/respuesta", web::get().to(get_solution))
            // Serve static files from the "./static" directory
            .service(fs::Files::new("/static", "./static").show_files_listing())
    })
    //server direction
    .bind("127.0.0.1:8080")?
    //ejecute
    .run()
    //server to run asynchronously
    .await
}
