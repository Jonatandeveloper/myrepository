document.addEventListener("DOMContentLoaded", function () {
    const initialState = [];

    //save the initial state
    storeInitialValues(initialState);

    // Listener for answer button
    document.getElementById("respuestaButton").addEventListener("click", function () {
        highlightIncorrectCells();
    });

    // Listener for Reset button
    document.getElementById("reset-button").addEventListener("click", function () {
        resetSudoku(initialState);
    });

    // Listener for all solution button
    document.getElementById("get-solution-btn").addEventListener("click", function () {
        fetchSolution();
    });

    // Listener for new sudoku button
    document.getElementById("refresh-button").addEventListener("click", function () {
        location.reload(); // Recarga la página
    });

    // Listener for empty board button
    document.getElementById("empty-button").addEventListener("click", function () {
        emptySudokuBoard();  // Call function to empty the board
    });
});

// Function to empty the Sudoku board
function emptySudokuBoard() {
    const rows = document.querySelectorAll("#sudoku-grid tr");

    rows.forEach((row) => {
        const cells = row.querySelectorAll("td input");
        cells.forEach((cell) => {
            // Reset each cell's value and enable it for editing
            cell.value = '';
            cell.disabled = false;
            cell.style.backgroundColor = '';
            cell.style.color = '';
        });
    });
}

// Function to get server solution
function fetchSolution() {
    fetch("/respuesta")
        .then(response => response.json())
        .then(solution => {
            const rows = document.querySelectorAll("#sudoku-grid tr");
            rows.forEach((row, i) => {
                const cells = row.querySelectorAll("td input");
                cells.forEach((cell, j) => {
                    const correctValue = solution[i][j];
                    cell.value = correctValue;
                    cell.disabled = true;
                    cell.style.backgroundColor = "#e6e6e6";
                    cell.style.color = "black";
                });
            });
        })
        .catch(error => console.error("Error to get solution:", error));
}

// Function to store the initial state of the cells
function storeInitialValues(initialState) {
    const rows = document.querySelectorAll("#sudoku-grid tr");
    rows.forEach((row, i) => {
        const rowData = [];
        const cells = row.querySelectorAll("td input");

        cells.forEach((cell) => {
            rowData.push(cell.value ? cell.value : ''); //If the cell is empty, save an empty string
        });

        initialState.push(rowData);
    });
}

// Function to highlight incorrect cells
function highlightIncorrectCells() {
    const rows = document.querySelectorAll("#sudoku-grid tr");

    const solution = [
        [5, 3, 4, 6, 7, 8, 9, 1, 2],
        [6, 7, 2, 1, 9, 5, 3, 4, 8],
        [1, 9, 8, 3, 4, 2, 5, 6, 7],
        [8, 5, 9, 7, 6, 1, 4, 2, 3],
        [4, 2, 6, 8, 5, 3, 7, 9, 1],
        [7, 1, 3, 9, 2, 4, 8, 5, 6],
        [9, 6, 1, 5, 3, 7, 2, 8, 4],
        [2, 8, 7, 4, 1, 9, 6, 3, 5],
        [3, 4, 5, 2, 8, 6, 1, 7, 9]
    ];

    rows.forEach((row, i) => {
        const cells = row.querySelectorAll("td input");
        cells.forEach((cell, j) => {
            const userInput = cell.value ? parseInt(cell.value) : null;
            const correctValue = solution[i][j];

            // If the value does not match the solution, we change the background color
            if (userInput !== correctValue && userInput !== null) {
                cell.style.backgroundColor = 'red';
                cell.style.color = 'white';
            }
            // if is null, also red cell
            else if (userInput === null || userInput === '') {
                cell.style.backgroundColor = 'red';
                cell.style.color = 'white';
            } else {
                cell.style.backgroundColor = '';
                cell.style.color = '';
            }
        });
    });
}

function resetSudoku(initialState) {
    const rows = document.querySelectorAll("#sudoku-grid tr");

    rows.forEach((row, i) => {
        const cells = row.querySelectorAll("td input");
        cells.forEach((cell, j) => {
            const initialValue = initialState[i][j];
            const isDisabled = cell.disabled;

            if (isDisabled) {
                cell.style.backgroundColor = '#e6e6e6';
                cell.style.color = 'black';
            } else {
                cell.value = initialValue === '' ? '' : initialValue;
                cell.disabled = false;
                cell.style.backgroundColor = '';
                cell.style.color = '';
            }
        });
    });
}

//check 
//check if number is valid in cell
function isValid(board, row, col, num) {
    // Check row
    for (let i = 0; i < 9; i++) {
        if (board[row][i] === num) return false;
    }

    // Check column
    for (let i = 0; i < 9; i++) {
        if (board[i][col] === num) return false;
    }

    // Check 3x3 subframe
    let startRow = Math.floor(row / 3) * 3;
    let startCol = Math.floor(col / 3) * 3;
    for (let i = startRow; i < startRow + 3; i++) {
        for (let j = startCol; j < startCol + 3; j++) {
            if (board[i][j] === num) return false;
        }
    }

    return true;
}

let solveTimeout = false; // Global variable to control time

function solveSudoku(board, startTime = Date.now(), maxTime = 1000) {
    if (Date.now() - startTime > maxTime) {
        solveTimeout = true; // Indicates that the maximum time has been exceeded
        return false;
    }

    for (let row = 0; row < 9; row++) {
        for (let col = 0; col < 9; col++) {
            if (board[row][col] === 0) {
                for (let num = 1; num <= 9; num++) {
                    if (isValid(board, row, col, num)) {
                        board[row][col] = num;

                        if (solveSudoku(board, startTime, maxTime)) {
                            return true;
                        }

                        board[row][col] = 0; // back
                    }
                }
                return false; // If no number can be entered
            }
        }
    }

    return true; // Sudoku resolved
}

function emptyCheck() {
    const board = [];
    const inputs = document.querySelectorAll('input');

    // Get dashboard values ​​from cells
    for (let i = 0; i < 9; i++) {
        board[i] = [];
        for (let j = 0; j < 9; j++) {
            const value = parseInt(inputs[i * 9 + j].value);
            if (isNaN(value) || value < 1 || value > 9) {
                board[i].push(0); // If the cell is empty or the value is invalid, enter 0
            } else {
                board[i].push(value); // If it has a numerical value, enter that value
            }
        }
    }

    // Check if the board has valid values
    const isValid = board.every(row => row.every(cell => (cell === 0 || (cell >= 1 && cell <= 9))));

    if (!isValid) {
        alert('Por favor, ingresa números válidos (del 1 al 9) en las celdas.');
        return;
    }

    // Reset the timeout variable
    solveTimeout = false;

    // Try to solve Sudoku
    const isSolvable = solveSudoku(board);

    if (solveTimeout) {
        // Show timeout modal if time is exceeded
        const timeoutModal = new bootstrap.Modal(document.getElementById('timeoutModal'), {});
        timeoutModal.show();
        return;
    }

    if (isSolvable) {
        // Initialize the modal after ensuring it is in the DOM
        const solutionModal = new bootstrap.Modal(document.getElementById('solutionModal'), {});
        solutionModal.show();

        // Listener for the "Show Solution" button
        const showSolutionButton = document.getElementById('showSolution');
        showSolutionButton.onclick = () => {
            for (let i = 0; i < 9; i++) {
                for (let j = 0; j < 9; j++) {
                    inputs[i * 9 + j].value = board[i][j] === 0 ? '' : board[i][j];
                }
            }
            solutionModal.hide();
        };
    } else {
        alert('El Sudoku no tiene solución. ¿Quieres intentarlo de nuevo?');
        emptySudokuBoard();
    }
}