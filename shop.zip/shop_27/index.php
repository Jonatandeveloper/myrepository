<!--cargo la cabecera-->
<?php require_once 'views/cabecera.phtml';?>

<!--Llamada al controlador-->
<div class="divcentral">
    <?php require_once 'controllers/compras_controller.php';?>
</div>

<!--cargo el footer-->
<?php require_once RAIZ . '/views/footer.phtml';?>