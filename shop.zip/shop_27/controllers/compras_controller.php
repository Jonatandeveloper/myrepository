<?php
//si no esta definida BASE_PATH la defines
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__)); // Un paso atrás para llegar a la raíz del proyecto
}
require_once BASE_PATH . '/models/compras_model.php';

//declaro la variable vacia
$accion = "";
//si existe, haces la accion del switch, sino pones el inicio
if (isset($_GET["action"]) == true) {
    $accion = $_GET['action'];
} else {
    require_once RAIZ . '/views/inicio_view.phtml';
}

switch ($accion) {
    case "inicio":
        //contenido del inicio
        require_once RAIZ . '/views/inicio_view.phtml';
        break;
        
        // contenido del menu añadir producto
    case "crear":
        require_once RAIZ . '/views/newproducto_view.phtml';
        break;
       
        //contenido del menu estadisctica
    case "fecha":
        require_once RAIZ . '/views/fecha_view.phtml';
        break;
        
        //archivo para que haga el filtro
    case "fechaResultado":
        require_once RAIZ . '/views/fecha_resultado_view.phtml';
        break;

    case "add": //Añadir nuevo producto a la lista
        $objeto = new Compras();
        $objeto->addProduct(
            $_POST['nombre'],
            $_POST['fecha'],
            $_POST['producto'],
            $_POST['precio'],
            $_POST['cantidad'],
            $_POST['categoria']
        );
        break;

    case "delete": //Eliminar producto de la lista
        $id = $_GET['id'];
        $objeto = new Compras();
        $objeto->deleteProduct($id);
        break;

    case "clonar": //Clonado de lista de compra
        $lista_a_clonar = $_GET['lista_a_clonar'];
        $nuevo_nombre = $_GET['nuevo_nombre'];
        $objeto = new Compras();
        $objeto->clonarLista($lista_a_clonar, $nuevo_nombre);
        break;

    case "openlist":
        if (!defined(constant_name: 'RAIZ')) {
            define('RAIZ', dirname(__DIR__)); // Un paso atrás para llegar a la raíz del proyecto
        }
        //Llamada al modelo
        require_once RAIZ . '/models/compras_model.php';
        //Instancia 
        $objeto = new Compras();
        //Obtengo la lista de categorias
        $categorias = $objeto->getCategorias();


        //Si he hecho una seleccion en el desplegable para mostrar SOLO UNA lista (viene del Ajax)
        if (isset($_POST['lista_seleccionada']) && $_POST['lista_seleccionada'] != "todas") {
            //Filtro
            $listas = $objeto->getFiltrada($_POST['lista_seleccionada']);
            require_once RAIZ . '/views/filtrada_view.phtml';
        } else {
            //Todas, sin filtro
            $listas = $objeto->getListas(); //Obtengo TODAS las listas    
            //Obtengo los nombres de las listas no repetidos
            $nombres_listas = $objeto->getListasNames();
            //Llamada a la vista
            require_once RAIZ . '/views/newproducto_view.phtml';
            require_once RAIZ . '/views/index_view.phtml';
        }
        break;
}
?>