<?php
if (!defined(constant_name: 'RAIZ')) {
    define('RAIZ', dirname(__DIR__)); // Un paso atrás para llegar a la raíz del proyecto
}
//Llamada al modelo
require_once RAIZ . '/models/compras_model.php';
//Instancia 
$objeto = new Compras();
//Obtengo la lista de categorias
$categorias = $objeto->getCategorias();

//Si he hecho una seleccion en el desplegable para mostrar SOLO UNA lista (viene del Ajax)
if (isset($_POST['lista_seleccionada']) && $_POST['lista_seleccionada'] != "todas") {
    //Filtro
    $listas = $objeto->getFiltrada($_POST['lista_seleccionada']);
    require_once RAIZ . '/views/filtrada_view.phtml';
} else {
    //Todas, sin filtro
    $listas = $objeto->getListas(); //Obtengo TODAS las listas    
    //Obtengo los nombres de las listas no repetidos
    $nombres_listas = $objeto->getListasNames();
    //Llamada a la vista

    require_once RAIZ . '/views/index_view.phtml';
}
?>