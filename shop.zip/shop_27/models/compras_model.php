<?php
if (!defined('RAIZ')) {
    define('RAIZ', dirname(__DIR__)); // Un paso atrás para llegar a la raíz del proyecto
}
require_once RAIZ . '/db/database.php';
class Compras extends Database
{
    //Constructor
    public function __construct()
    {
        $this->conectar();
    }

    //Funcion obtener listas (SELECT)
    public function getListas()
    {
        $qry = "SELECT l.*, c.nombre AS Cat  FROM listas l INNER JOIN categorias c 
        ON l.categoria = c.id";
        $result = $this->conn->query($qry);
        return $result;
    }

    //Función que inserta nuevo producto a la lista (INSERT)
    public function addProduct($nombre, $fecha, $producto, $precio, $cantidad, $categoria)
    {
        $qry = "INSERT INTO listas (nombre,fecha,producto,precio,cantidad,categoria) 
                VALUES ('" . $nombre . "','" . $fecha . "','" . $producto . "','" . $precio . "','" . $cantidad . "','" . $categoria . "')";
        $this->conn->query($qry);
        header('Location:../index.php?action=openlist');
        return true;
    }

    //Función que eliminar un registro de la lista (DELETE)
    public function deleteProduct($id)
    {
        $qry = "DELETE FROM listas WHERE id = " . $id;
        $this->conn->query($qry);
        header('Location:../index.php?action=openlist');
        return true;
    }

    //Funcion que devuelve las categorías
    public function getCategorias()
    {
        $qry = "SELECT c.id, c.nombre FROM categorias c ORDER BY c.nombre";
        $result = $this->conn->query($qry);
        return $result;
    }

    //Funcion que devuelve los nombres de las listas que haya
    public function getListasNames()
    {
        $qry = "SELECT DISTINCT l.nombre FROM listas l";
        $result = $this->conn->query($qry);
        return $result;
    }

    //Función que devuelve la lista filtrada por nombre
    public function getFiltrada($nombre)
    {
        $qry = "SELECT l.*, c.nombre AS Cat  FROM listas l INNER JOIN categorias c 
        ON l.categoria = c.id WHERE l.nombre = '" . $nombre . "'";
        $result = $this->conn->query($qry);
        return $result;
    }

    //funcion que devuelve lista filtrada por fecha
    public function estadistica($dateIni, $dateEnd)
    {
        $query = "SELECT l.*,c.nombre AS Cat
                    FROM listas l
                    INNER JOIN categorias c
                    ON l.categoria = c.id
                    WHERE fecha>='$dateIni'
                    AND fecha<='$dateEnd'";

        $consulta = $this->conn->query($query);
        if ($consulta) {
            // Recoger los datos
            $resultados = $consulta->fetch_all(MYSQLI_ASSOC);
            // Convertir resultados a JSON
            $resultados_json = json_encode($resultados);
            return $resultados_json;

        } else {
            return json_encode([]); // En caso de error, retornar un JSON vacío
        }
    }

    public function clonarLista($lista_inicial, $nuevo_nombre)
    {
        //Obtengo los registros de la lista original/inicial (la que quiero clonar)
        $qry = "SELECT * FROM listas WHERE nombre LIKE '" . $lista_inicial . "'";
        $result = $this->conn->query($qry);
        //Recorro ese array para LINEA A LINEA insertar nuevo registro con nombre de lista nuevo
        foreach ($result as $linea) {
            $qry = "INSERT INTO listas(nombre,fecha,producto,precio,cantidad,categoria) 
                    VALUES('" . $nuevo_nombre . "','" . date('Y-m-d') . "','" . $linea['producto'] . "'
                    ,'" . $linea['precio'] . "','" . $linea['cantidad'] . "',
                    '" . $linea['categoria'] . "')";
            $this->conn->query($qry);
        }
        return true;
    }
}
?>