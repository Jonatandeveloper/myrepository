<?php

class Database {
    private $server = "localhost";
    private $usuario = "root";
    private $pwd = "";
    private $dbname = "compras";
    public $conn;

    public function __construct(){
        
    }
    // Método para obtener la conexión
    public function conectar() {
        $this->conn = null;

        try {
            $this->conn = new mysqli($this->server, $this->usuario, $this->pwd, $this->dbname);

            // Verificar la conexión
            if ($this->conn->connect_error) {
                throw new Exception("Connection failed: " . $this->conn->connect_error);
            }
        } catch (Exception $e) {
            echo "Error de conexión: " . $e->getMessage();
        }

        return $this->conn;
    }
}
?>