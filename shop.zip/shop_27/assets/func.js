$(document).ready(function () {
    //HACER CLIC EN BOTON DE FILTRO
    $("#btnfiltrar").on("click", function () {
        //Obtener el nombre de la lista
        seleccionado = $("#nomlista").val();
        //AJAX
        $.ajax({
            url: 'controllers/index_controller.php',
            type: 'POST',
            cache: false,
            data: { lista_seleccionada: seleccionado },
            success: function (response) {
                $("#tblresultados").html(response);
                if (seleccionado != "todas")
                    $("#btnclonar").css("display", "inline");
                else
                    $("#btnclonar").css("display", "none");
            }
        });
    });

    //HACER CLIC EN BOTON CLONAR
    $("#btnclonar").on("click", function () {
        //Obtener el nombre de la lista
        seleccionado = $("#nomlista").val();
        nuevo_nombre = prompt("Escribe el nombre de la nueva lista:");
        //AJAX
        $.ajax({
            url: 'controllers/compras_controller.php',
            type: 'GET',
            cache: false,
            data: { action: "clonar", lista_a_clonar: seleccionado, nuevo_nombre: nuevo_nombre },
            success: function (response) {
                alert("CLONADO CORRECTO");
                location.reload();
            }
        });
    });


    //Hacer clic en el boton de filtrar fechas
    $("#idformulario1").on('submit', function (event) {
        event.preventDefault(); // Prevenir el envío tradicional del formulario
        $.ajax({
                url: 'controllers/compras_controller.php?action=fechaResultado',
                type: 'POST',
                data: {
                    "dateIni": $("#dateIni").val(),
                    "dateEnd": $("#dateEnd").val(),
                    "llamada": "estadistica"
                },
                success: function (response) {
                    document.getElementById("tablafiltrada").innerHTML = response;
                    console.log('Respuesta del servidor:', response);
                },
                error: function (xhr, status, error) {
                    alert("adios");
                    console.error('Error en la solicitud AJAX:', error);
                }
        });
    });

});