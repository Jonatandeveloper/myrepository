CREATE DATABASE /*!32312 IF NOT EXISTS*/`compras` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `compras`;

/*Table structure for table `categorias` */

DROP TABLE IF EXISTS `categorias`;

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(90) NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `categorias` */

insert  into `categorias`(`id`,`nombre`) values 
(1,'Panaderia'),
(2,'Carne'),
(3,'Lácteos'),
(4,'Refrescos'),
(5,'Otros');

/*Table structure for table `listas` */

DROP TABLE IF EXISTS `listas`;

CREATE TABLE `listas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  `producto` varchar(50) NOT NULL,
  `precio` double NOT NULL DEFAULT 0,
  `cantidad` int(11) NOT NULL DEFAULT 0,
  `categoria` int(11) NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `listas` */

insert  into `listas`(`id`,`nombre`,`fecha`,`producto`,`precio`,`cantidad`,`categoria`) values 
(1,'Julio','2024-09-23','Cerveza',0.82,12,4),
(2,'Julio','2024-09-23','Pan',0.6,2,1),
(3,'Julio','2024-09-23','Carne',4.5,1,2),
(5,'Julio','2024-08-25','Cerveza Negra',5,80,4),
(6,'Julio','2024-09-15','Cerveza Rubia',3.75,200,4),
(7,'Julio','2024-07-20','Cerveza Artesanal',5.25,150,4),
(8,'Julio','2024-06-10','Cerveza Clásica',3,250,4),
(9,'Agosto','2024-08-12','Cerveza de Trigo',4.8,170,4),
(10,'Agosto','2024-05-30','Cerveza Artesanal',4.6,130,4),
(11,'Agosto','2024-09-05','Cerveza Fuerte',6.5,50,4),
(12,'Agosto','2024-07-18','Cerveza Belga',5.8,90,4),
(13,'Agosto','2024-08-22','Cerveza Fuerte',6.8,60,4),
(14,'Agosto','2024-06-15','Cerveza Rubia',3.9,180,4),
(15,'Agosto','2024-09-08','Cerveza Roja',4.2,140,4),
(16,'Agosto','2024-05-20','Pan',5.1,110,4),
(24,'Agosto','2024-09-23','Comida gato',3.25,1,5),
(30,'Septiembre','2024-09-23','Comida gato',3.25,1,5),
(31,'Septiembre','2024-09-23','Comida gato',3.25,1,5),
(32,'Septiembre','2024-09-23','Comida gato',3.25,1,5),
(33,'Septiembre','2024-09-23','Comida gato',3.25,1,5),
(53,'Octubre','2024-09-24','Comida gato',3.25,1,5),
(54,'Octubre','2024-09-24','Comida gato',3.25,1,5),
(55,'Octubre','2024-09-24','Comida gato',3.25,1,5),
(56,'Octubre','2024-09-24','Comida gato',3.25,1,5),
(57,'Octubre','2024-09-24','Vino',4,2,4);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
